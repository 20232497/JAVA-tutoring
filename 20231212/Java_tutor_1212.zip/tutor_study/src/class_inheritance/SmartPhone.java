package class_inheritance;

public class SmartPhone extends Phone{
	//필드 선언(declaration field)
	public boolean wifi; // 참과 거짓 둘중 하나
	
	//생성자 선언(declaration constructor)
	//생성자는 클래스 이름과 동일, 리턴 타입 x, 객체가 생성될때 자동 호출
	//생성자는 클래스에 무조건 하나는 존재, if 없으면 컴파일러가 [기본생성자] 자동으로 생성 >>
	//생성자 코드가 하나라도 있다면, 컴파일러는 기본 생성자가 없어도 생성 x
	public SmartPhone(String model, String color) {
		this.model = model;
		this.color = color;
	}
	//메소드 선언(declaration method)
	public void setWifi(boolean wifi) {
		this.wifi = wifi;
		System.out.println("와이파이 상태를 변경했습니다. ");
	}
	public void internet() {
		System.out.println("인터넷에 연결합니다. ");
	}
	
}
