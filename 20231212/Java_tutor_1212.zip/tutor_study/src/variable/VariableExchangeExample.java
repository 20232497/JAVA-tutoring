package variable;

public class VariableExchangeExample {
	public static void main(String[] args) {
		
		int x = 3;
		int y = 5;
		System.out.println("x: " + x + "| y: " + y);
		
		int temp = x;  //변수 temp 에 x 값 저장.
		x = y;		   //변수 x에 y 값 저장.
		y = temp;      //y에 temp에 저장된 x 값 저장.
		System.out.println("x: " + x + "| y: " + y);
	}
}
