package variable;

public class FloatDoubleExample {
	public static void main(String[] args) {
		
		float var1 = 0.123456789f;
		double var2 = 0.1234567890123456789;
		System.out.println("var1: " + var1);
		System.out.println("var2: " + var2);
		
		double var3 = 3e6;   //3 x 10^6 >> 왼쪽으로 6칸
		float var4 = 3e6F;   //3 x 10^6 >> 왼쪽으로 6칸
		double var5 = 2e-3;  //2 x (-10^3) == 1/10^3 >> 오른쪽으로 3칸
		System.out.println("var3: " + var3);
		System.out.println("var4: " + var4);
		System.out.println("var5: " + var5);
	}
}
