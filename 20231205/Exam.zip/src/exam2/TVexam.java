package exam2;

public class TVexam {
	public static void main(String[] args) {
		
		ColorTV myTV = new ColorTV(32, 1024);
		myTV.printProperty();
	}
}
