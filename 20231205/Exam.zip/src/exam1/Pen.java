package exam1;

public class Pen {
	public int width;
	public int amount;
	public String color;
	
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public void refill(int n) {
		amount = n;
	}
}
