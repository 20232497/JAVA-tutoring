package exam1;

public class SharpPencil extends Pen{
	
}
