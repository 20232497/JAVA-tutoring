package exam4;

public class Book {
	//생성자 오버로딩의 사용
	private String book;
	private String author;
	
	Book() {
		System.out.println("책 : " + "비어있음" + " | " + "작가: " + "비어있음");
	}
	Book(String book) {
		System.out.println("책 : " + book + " | " + "작가: " + "작자미상");
	}
	Book(String book, String author) {
		System.out.println("책 : " + book + " | " + "작가: " + author);
	}

	public static void main(String[] args) {
		
		Book book1 = new Book("어린왕자", "생택쥐페리");
		
		Book book2 = new Book("춘항젼");
		
		Book book3 = new Book();
	}
}
