package exam1;

public class BallPen extends Pen{
	
}
