package exam1;

public class FountainPen extends Pen{

}
