package exam3;

public class ColorTV {
	private int size;
	private int color;
	
	public ColorTV(int size, int color) {
		this.size = size;
		this.color = color;
	}
	
	protected int getSize() {
		return size;
	}
	protected int getColor() {
		return color;
	}
	
	public void printProperty() {
		System.out.println("[" + size + "]인치 [" + color + "]컬러 ");
	}
}
